### TODO list for myself and maintainers 

 - move from http://aamirafridi.com/jquery/jquery-marquee-plugin to github pages
 - module support e.g. https://github.com/kenwheeler/slick/blob/master/slick/slick.js#L19-L26
 - check if we can remove the animation with javascript and just relay on CSS animations (check support)
 - review PRs
 - push the latest version on jsdelivr
 - [watch](https://help.github.jp/enterprise/2.11/user/articles/watching-and-unwatching-repositories/) this plugin and monitor issues
